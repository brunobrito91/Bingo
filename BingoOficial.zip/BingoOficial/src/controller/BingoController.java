/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import comunicacao.Cliente;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import tela.TelaBingo;

/**
 *
 * @author bruno.abreu
 */
public class BingoController {

    private List<Integer> numeros;
    private Cliente _cliente;

    public BingoController() {
        numeros = new ArrayList<>();
    }

    public void adicionarNumero(Integer numero) {
        numeros.add(numero);
    }

    public void excluirNumero(Integer numero) {
        numeros.remove(numero);
    }

    public void gritarBingo() {
        int tamanho = numeros.size() + 1;
        byte[] mensagem = new byte[tamanho];
        mensagem[0] = 'B';
        int i = 1;
        for (Integer numero : numeros) {
            mensagem[i] = (byte) (int) numero;
        }
        _cliente.enviarMensagem(mensagem);
    }

    public void conectar() throws IOException {
        _cliente = new Cliente("101.100.21.85", 9876);
        _cliente.start();
    }

    public boolean isConectado() {
        return (_cliente.isAlive() && _cliente.isConectado());

    }

    public void addClienteListener(TelaBingo telaBingo) {
        _cliente.addClienteListener(telaBingo);
    }

}
