package main;

import comunicacao.Cliente;
import controller.BingoController;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import tela.TelaBingo;
import tela.TelaInicial;

public class Principal {

    public static void main(String[] args) {
        try {
            //       TelaInicial telaInicial = new TelaInicial();
//       telaInicial.setVisible(true);
//            TelaBingo telaBingo = new TelaBingo();
//            Cliente cliente = new Cliente("101.100.21.85", 9876);
//            cliente.addClienteListener(telaBingo);
//            cliente.start();
//            telaBingo.setVisible(true);
            BingoController bingoController = new BingoController();
            bingoController.conectar();
            if (bingoController.isConectado()) {
                TelaBingo telaBingo = new TelaBingo(bingoController);
                telaBingo.setVisible(true);
            }
        } catch (IOException ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
