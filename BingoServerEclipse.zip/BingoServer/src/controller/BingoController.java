package controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class BingoController {
	List<Integer> numeros = new ArrayList<Integer>();
	private int next = 0;
	private boolean ganhador = false;

	public BingoController() {
		gerarNumeros();
	}

	private void gerarNumeros() {
		for (int i = 1; i <= 75; i++) {
			numeros.add(i);
		}
		Collections.shuffle(numeros);
	}

	public boolean hasGanhandor() {
		return ganhador;
	}

	public List<Integer> getNumerosParaCartelas() {
		List<Integer> n = new ArrayList<>();
		n.addAll(numeros);
		Collections.shuffle(n);
		List<Integer> numerosCartela = n.subList(0, 24);
		Collections.sort(numerosCartela);

		return numerosCartela;

	}

	public boolean hasNextNumeroSorteado() {
		return (numeros.size() > next);
	}

	public Integer getNextNumeroSorteado() {
		if (hasNextNumeroSorteado()) {
			Integer numero = numeros.get(next);
			next++;
			return numero;
		}
		return -1;
	}

	public boolean gritarBingo(List<Integer> numeros) {
		if (numeros.containsAll(this.numeros)) {
			ganhador = true;
		} else {
			ganhador = false;
		}
		return ganhador;
	}
}
