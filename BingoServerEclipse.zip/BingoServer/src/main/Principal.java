package main;

import comunicacao.Servidor;

public class Principal {

	public static void main(String[] args) {
		Servidor servidor = new Servidor(9876);
		servidor.iniciarServidor();
	}

}
