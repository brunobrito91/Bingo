package comunicacao;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class Servidor extends Thread {
	private ServerSocket _servidor;
	private List<Socket> _clientes;
	private int port;
	private boolean aceitandoClientes = true;

	public Servidor(int port) {
		this.port = port;
		_clientes = new ArrayList<>();
	}

	public void iniciarServidor() {
		System.out.println("Servidor iniciado");
		try {
			_servidor = new ServerSocket(port);
			this.start();
			while (true) {
				Socket socketCliente;
				System.out.println("Aguardando cliente...");
				socketCliente = _servidor.accept();
				if (aceitandoClientes) {
					System.out.println("Cliente conectado: " + socketCliente.getInetAddress().getHostAddress());
					_clientes.add(socketCliente);
				} else {
					socketCliente.close();
				}
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public List<Socket> getClientes() {
		return _clientes;
	}

	@Override
	public void run() {
		System.out.println("Run Servidor");
		while (aceitandoClientes) {
			try {
				Thread.sleep(10000);
				if (_clientes.size() > 0) {
					System.out.println("Comeco Servidor");
					aceitandoClientes = false;
					BingoServidor bingoServidor = new BingoServidor(_clientes);
					bingoServidor.start();
					Thread.sleep(1000);
					while (bingoServidor.isJogando()) {

					}
					System.out.println("Fim Servidor");
					aceitandoClientes = true;
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

	}
}
