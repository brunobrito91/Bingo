package comunicacao;

import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;
import java.util.List;

import controller.BingoController;

public class BingoServidor extends Thread {
	private List<Socket> clientes;
	private BingoController bingoController;
	private boolean jogando = false;

	public BingoServidor(List<Socket> clientes) {
		bingoController = new BingoController();
		this.clientes = clientes;
		for (Socket cliente : clientes) {
			Cliente c = new Cliente(cliente, bingoController);
			c.start();
		}
	}

	@Override
	public void run() {
		jogando = true;
		List<Integer> numerosCartela;
		byte[] mensagem;
		for (Socket cliente : clientes) {
			numerosCartela = bingoController.getNumerosParaCartelas();
			mensagem = new byte[numerosCartela.size()];
			mensagem[0] = 'S';
			for (int i = 1; i < mensagem.length; i++) {
				mensagem[i] = (byte) (int) numerosCartela.get(i);
			}
			enviarMensagem(cliente, mensagem);
		}
		System.out.println("cOMECO");
		while (!bingoController.hasGanhandor() || !bingoController.hasNextNumeroSorteado()) {
			Integer numeroSorteado = bingoController.getNextNumeroSorteado();
			mensagem = new byte[2];
			mensagem[0] = 'N';
			mensagem[1] = (byte) (int) numeroSorteado;
			enviarMensagem(mensagem);
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("fIM");
		mensagem = new byte[2];
		mensagem[0] = 'F';
		mensagem[1] = (byte) (bingoController.hasGanhandor() ? 1 : 0);
		enviarMensagem(mensagem);

		jogando = false;
	}

	private void enviarMensagem(Socket cliente, byte[] mensagem) {
		if (cliente.isConnected()) {
			PrintStream outputStream;
			try {
				outputStream = new PrintStream(cliente.getOutputStream());
				outputStream.write(mensagem);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	private void enviarMensagem(byte[] mensagem) {
		for (Socket cliente : clientes) {
			enviarMensagem(cliente, mensagem);
		}
	}

	public boolean isJogando() {
		return jogando;
	}

}
