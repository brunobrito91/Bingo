package comunicacao;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

import controller.BingoController;

public class Cliente extends Thread {
	private Socket _cliente;
	private BingoController _bingoController;

	public Cliente(Socket cliente, BingoController bingoController) {
		_cliente = cliente;
		_bingoController = bingoController;
	}

	@Override
	public void run() {
		while (_cliente.isConnected()) {
			InputStream inputStream;
			try {
				inputStream = _cliente.getInputStream();
				int tamanhoBuffer = inputStream.available();
				if (tamanhoBuffer > 0) {
					byte[] mensagem = new byte[tamanhoBuffer];
					inputStream.read(mensagem);
					if (mensagem[0] == 'B') {
						System.out.println("Chegou um B");
						List<Integer> numeros = new ArrayList<>();
						for (int i = 1; i < mensagem.length; i++) {
							System.out.println(_cliente.getInetAddress() + ": " + mensagem[i]);
							numeros.add((int) mensagem[i]);
						}
						if (_bingoController.gritarBingo(numeros)) {
							PrintStream outputStream;
							try {
								outputStream = new PrintStream(_cliente.getOutputStream());
								mensagem = new byte[2];
								mensagem[0] = 'G';
								mensagem[1] = mensagem[1] = (byte) (_bingoController.hasGanhandor() ? 1 : 0);
								outputStream.write(mensagem);
							} catch (IOException e) {
								e.printStackTrace();
							}
						}

					}

				}
			} catch (IOException e) {
				e.printStackTrace();
			}
			try {
				Cliente.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		try {
			_cliente.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
