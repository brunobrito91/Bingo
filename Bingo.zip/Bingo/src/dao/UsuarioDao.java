package dao;

import connection.MySqlConnnection;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import model.Usuario;

public class UsuarioDao {

    private Connection connection;
    private PreparedStatement preparedStatement;

    public UsuarioDao() throws SQLException {
        connection = MySqlConnnection.getConnection();
    }

    public void adiciona(Usuario usuario) throws SQLException {
        String sql = "insert into usuario(email, senha, primeiraDataMes, qtdVitoriasMes) values (?,?,?,?)";

        preparedStatement = connection.prepareStatement(sql);

        preparedStatement.setString(1, usuario.getEmail());
        preparedStatement.setString(2, usuario.getSenha());

        Calendar calendar = Calendar.getInstance();
        Date date = new Date(calendar.getTimeInMillis());
        preparedStatement.setDate(3, date);
        
        preparedStatement.setInt(4, 0);

        preparedStatement.execute();
        preparedStatement.close();
    }

    public Usuario recuperar(String email) throws SQLException {
        String sql = "select * from usuario where email = ?";

        preparedStatement = connection.prepareCall(sql);
        preparedStatement.setString(1, email);

        ResultSet resultSet = preparedStatement.executeQuery();

        Usuario usuario = null;
        if (resultSet.first()) {
            String e = resultSet.getString("email");
            String senha = resultSet.getString("senha");
            usuario = new Usuario(e, senha);
        }

        return usuario;
    }

    public List<Usuario> recuperarTodos() throws SQLException {
        String sql = "select * from usuario";

        preparedStatement = connection.prepareCall(sql);

        ResultSet resultSet = preparedStatement.executeQuery();

        List<Usuario> usuarios = new ArrayList<>();

        while (resultSet.next()) {
            String email = resultSet.getString("email");
            String senha = resultSet.getString("senha");
            usuarios.add(new Usuario(email, senha));
        }

        return usuarios;
    }

}
