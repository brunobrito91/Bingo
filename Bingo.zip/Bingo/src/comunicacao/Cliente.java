/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comunicacao;

import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import listener.ClienteListener;

/**
 *
 * @author bruno.abreu
 */
public class Cliente implements Runnable {

    private Socket _cliente;
    private ClienteListener clienteListener;

    public Cliente(String ip, int porta) throws IOException {
        _cliente = new Socket(ip, porta);
    }

    public void addClienteListener(ClienteListener clienteListener) {
        this.clienteListener = clienteListener;
    }

    @Override
    public void run() {
        while (_cliente.isConnected()) {
            InputStream inputStream;
            try {
                inputStream = _cliente.getInputStream();
                int tamanhoBuffer = inputStream.available();
                if (tamanhoBuffer > 0) {
                    byte[] mensagem = new byte[tamanhoBuffer];
                    inputStream.read(mensagem);
                    for (int i = 0; i < mensagem.length; i++) {
                        System.out.println(_cliente.getInetAddress() + ": " + mensagem[i]);
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        try {
            _cliente.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
