package main;

import comunicacao.Cliente;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import tela.TelaInicial;

public class Principal {

    public static void main(String[] args) {
        try {
            //       TelaInicial telaInicial = new TelaInicial();
//       telaInicial.setVisible(true);
            Cliente cliente = new Cliente("101.100.21.85", 9876);
            cliente.run();
        } catch (IOException ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
