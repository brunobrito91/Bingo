/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.UsuarioDao;
import java.sql.SQLException;
import model.Usuario;

/**
 *
 * @author bruno.abreu
 */
public class UsuarioController {
    
    private UsuarioDao usuarioDao;
    
    public UsuarioController() throws SQLException{
        usuarioDao = new UsuarioDao();
    }
    
    public boolean isUsuarioValido(Usuario usuario) throws SQLException {
        Usuario u = usuarioDao.recuperar(usuario.getEmail());
        return (u != null) && (u.getSenha().equals(usuario.getSenha()));
    }
    
    public void adiciona(Usuario usuario) throws SQLException{
        usuarioDao.adiciona(usuario);
    }

}
